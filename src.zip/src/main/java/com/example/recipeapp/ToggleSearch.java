package com.example.recipeapp;

public class ToggleSearch {

    private boolean Recipes;
    private boolean Users;

    public ToggleSearch(){
        Recipes=true;
        Users=false;
    }

    public void SetDefaults(){
        Recipes=true;
        Users=false;
    }

    public void ToggleSwitch(){
        if (Recipes==true){
            Recipes=false;
            Users=true;
        }
        else {
            Recipes=true;
            Users=false;
        }
    }

    public boolean getRecipes(){
        return Recipes;
    }

    public boolean getUsers(){
        return Users;
    }

}
