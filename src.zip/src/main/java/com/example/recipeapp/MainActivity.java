package com.example.recipeapp;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.MultiAutoCompleteTextView;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import android.content.Context;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Spinner;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.io.IOException;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private ToggleSearch toggleSearch;
    private LinearLayout recipeContainer;
    private View filterLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        //toggle search buttons
        Button recipesButtons = findViewById(R.id.recipesButton);
        Button usersButton = findViewById(R.id.usersButton);
        toggleSearch = new ToggleSearch();
        recipesButtons.setSelected(true);
        usersButton.setSelected(false);

        //container for recipe boxes
        recipeContainer = findViewById((R.id.recipeContainer));


        //populate combo boxes for filters
        //String link = "";
        //MultiAutoCompleteTextView multiAutoCompleteTextViewIngredients = findViewById(R.id.multiAutoCompleteTextViewIngredients);
        //populateIngredients(link, multiAutoCompleteTextViewIngredients);
        //populateIngredientsTemp();


        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }

    public void onToggleRecipeUsers(View v) { //will allow users to switch between searching for users and recipes
        toggleSearch.ToggleSwitch();
        Button recipesButtons = findViewById(R.id.recipesButton);
        Button usersButton = findViewById(R.id.usersButton);
        recipesButtons.setSelected(toggleSearch.getRecipes());
        usersButton.setSelected(toggleSearch.getUsers());
    }//switch between recipe and user search

    public void onFilter(View v) { //if the user clicks filter then a filter menu will show
        if (toggleSearch.getRecipes() == false) {
            onToggleRecipeUsers(v);
            Toast.makeText(this, "Switched to recipe search", Toast.LENGTH_SHORT).show();
        }
        filterLayout = findViewById(R.id.filter_layout);
        ShowFilterBar(v);
    }//show filter menu

    private void ShowFilterBar(View v) {
        if (filterLayout != null) {
            filterLayout.setVisibility(View.VISIBLE);
        }
        else{
            LayoutInflater inflater = LayoutInflater.from(this);
            filterLayout = inflater.inflate(R.layout.filter_layout, null);

            // Add the inflated layout to the parent layout
            ConstraintLayout parentLayout = findViewById(R.id.main); // Change to your parent layout ID
            parentLayout.addView(filterLayout);
        }
//        ConstraintLayout filter_layout = findViewById(R.id.filter_layout);
//        ConstraintLayout.LayoutParams layoutParams = (ConstraintLayout.LayoutParams) filter_layout.getLayoutParams();
//        layoutParams.topToTop = ConstraintLayout.LayoutParams.PARENT_ID;
//        filter_layout.setLayoutParams(layoutParams);

    } //helper function for onFilter

    public void onCloseFilterBar(View v) { //if user wants to close filter
        filterLayout.setVisibility(View.GONE);
        ConstraintLayout filter_layout = findViewById(R.id.filter_layout);
        ConstraintLayout.LayoutParams layoutParams = (ConstraintLayout.LayoutParams) filter_layout.getLayoutParams();
        layoutParams.topToTop = ConstraintLayout.LayoutParams.UNSET;
        filter_layout.setLayoutParams(layoutParams);
    }//close filter menu


    public void onSearch(View v) {
        TextView dynamicText = findViewById(R.id.dynamicText);
        EditText searchEditText = findViewById(R.id.searchEditText);
        String userInput = searchEditText.getText().toString();
        if (userInput == "") {//and if no filteres where selected
            Toast.makeText(this, "Please enter something to search.", Toast.LENGTH_SHORT).show();
            //break?
        }

        dynamicText.setText("Search Results for " + userInput);

        if (toggleSearch.getRecipes() == true) {
            //10 will be replaces with int from NumResults method.
            //clear whatever is already that
            for (int i = 0; i < 10; i++) {
                View recipeBoxView = LayoutInflater.from(MainActivity.this).inflate(R.layout.recipe_box_layout, recipeContainer, false);
                recipeContainer.addView(recipeBoxView);
            }
        } else {
            //clear whatever is already that
            for (int i = 0; i < 10; i++) {
                View UserBoxView = LayoutInflater.from(MainActivity.this).inflate(R.layout.user_box_layout, recipeContainer, false);
                recipeContainer.addView(UserBoxView);
            }
        }

    }

    private void ChangeRecipebox(View v, String RecipeName, String Username, int NumComments, int NumRating, String IMGName) {
        //LayoutInflater inflater = LayoutInflater.from(this);
        //View recipeBoxView=inflater.inflate(R.layout.recipe_box_layout,null);
        //TextView RecipeNameTextView = recipeBoxView.findViewById(R.id.RecipeNameTextView);
        View recipeNameText = findViewById(R.id.recipeNameTextView);
    }

    public interface ResponseCallback {
        void onResponse(String responseData);

        void onFailure(IOException e);
    } //for doRequest

    public void doRequest(String urllink, final ResponseCallback callback) {

        OkHttpClient client = new OkHttpClient();
        Request request = new Request.Builder()
                .url(urllink)
                .build();

        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                callback.onFailure(e);
            }

            @Override
            public void onResponse(Call call, final Response response) throws IOException {
                if (!response.isSuccessful()) {
                    callback.onFailure(new IOException("Unexpected code " + response));
                    return;
                }

                // Read data on the worker thread
                final String responseData = response.body().string();
                callback.onResponse((responseData));

            }
        });
    }//fetches data from link given

//    public ArrayList<String> populateLists(String urllink) {
//        doRequest(urllink, new ResponseCallback() {
//            ArrayList<String> listofitems = new ArrayList<>();
//            @Override
//            public void onResponse(String responseData) {
//                String[] List = responseData.split(",");
//                for (String item :List){
//                }
//
//            }
//            @Override
//            public void onFailure(IOException e) {
//                e.printStackTrace();
//
//            }
//        });
//
//
//    }//populates ingredients box for filter menu

    public void populateIngredientsTemp(ArrayList<String> list) {
        LinearLayout checkboxGroupContainer = findViewById(R.id.checkboxGroupContainer);
        for (String item : list) {
            CheckBox checkBox = new CheckBox(this);
            checkBox.setText(item);
            checkboxGroupContainer.addView(checkBox);
        }

        ScrollView scrollView = findViewById(R.id.ScrollFilter);
        scrollView.setEnabled(true);
        scrollView.setFocusable(true);
    }

    public void onIngredientsfilter(View v) {
        ArrayList<String> ingredients = new ArrayList<>();
        ingredients.add("Flour");
        ingredients.add("Sugar");
        ingredients.add("Salt");
        ingredients.add("Butter");
        ingredients.add("Eggs");
        ingredients.add("Milk");
        ingredients.add("Baking Powder");
        ingredients.add("Baking Soda");
        ingredients.add("Oil");
        ingredients.add("Vanilla Extract");
        ingredients.add("Onions");
        ingredients.add("Garlic");
        ingredients.add("Tomatoes");
        ingredients.add("Potatoes");
        ingredients.add("Carrots");
        ingredients.add("Bell Peppers");
        ingredients.add("Chicken");
        ingredients.add("Beef");
        ingredients.add("Fish (e.g., salmon, cod)");
        ingredients.add("Rice (e.g., white rice, brown rice)");
        ingredients.add("Pasta");
        ingredients.add("Bread");
        ingredients.add("Apples");
        ingredients.add("Bananas");
        ingredients.add("Oranges");
        ingredients.add("Lemons");
        ingredients.add("Strawberries");
        ingredients.add("Grapes");
        ingredients.add("Spinach");
        ingredients.add("Broccoli");
        ingredients.add("Cauliflower");
        ingredients.add("Cabbage");
        ingredients.add("Lettuce");
        ingredients.add("Avocado");
        ingredients.add("Peas");
        ingredients.add("Corn");
        ingredients.add("Green Beans");
        ingredients.add("Almonds");
        ingredients.add("Walnuts");
        ingredients.add("Cashews");
        ingredients.add("Pecans");
        ingredients.add("Cheese (e.g., cheddar, mozzarella, parmesan)");
        ingredients.add("Yogurt");
        ingredients.add("Sour Cream");
        ingredients.add("Honey");
        ingredients.add("Oats");
        ingredients.add("Cinnamon");
        ingredients.add("Nutmeg");
        ingredients.add("Ginger");
        ingredients.add("Chili Powder");
        populateIngredientsTemp(ingredients);



    }
}



